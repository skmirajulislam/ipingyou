/**
 * ============================================================
 *  Client Mode — "Access a Remote Machine"
 * ============================================================
 *  1. Prompt for the remote host's UID
 *  2. Resolve UID → ENCRYPTED blob from the Broker
 *  3. DECRYPT tunnel URL locally using shared key
 *  4. Execute SSH/SCP through the Cloudflare tunnel proxy
 *
 *  Security: The broker only returns { iv, ciphertext }.
 *  Decryption happens ONLY on this machine.
 * ============================================================
 */

import { execa } from 'execa';
import chalk from 'chalk';
import inquirer from 'inquirer';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { cleanupAll, trackPID, untrackPID, addCleanupHook } from '../lib/cleanup.js';
import { createSpinner, sshSpinner, networkSpinner, fileTransferSpinner, showConnectionTrace, simulateTransferProgress } from '../lib/animations.js';
import { getConfig, saveAlias } from '../lib/config.js';
import { pushTelemetry, requestHostApproval, resolveUID, revokeUID, waitForApproval } from '../lib/broker.js';
import { calculateChecksum } from '../lib/checksum.js';
import { promptLocalPath, promptRemotePath } from '../lib/path-browser.js';
import { buildSshArgs, extractHostname, formatScpRemotePath, getKnownHostsOptions, getSshControlOptions, quoteRemoteShell } from '../lib/ssh.js';
import { buildTmuxSessionName, TMUX_SOCKET_PATH } from '../lib/tmux.js';
import open from 'open';
import { secureSensitiveUrl } from '../lib/secure-print.js';
import { cleanupSessionLog, initSessionLog, logSessionEvent, recordEvent } from '../lib/session-log.js';

let BROKER_URL = process.env.BROKER_URL || 'https://ipingyou.onrender.com';

async function promptUsername() {
  const { username } = await inquirer.prompt([
    {
      type: 'input',
      name: 'username',
      message: 'SSH username on the remote machine:',
      default: process.env.USER || process.env.USERNAME || 'root',
      validate: (v) => v.trim().length > 0 || 'Username is required',
    },
  ]);
  return username.trim();
}

function normalizePrivateKey(privateKey) {
  const normalized = String(privateKey || '').replace(/\\n/g, '\n').replace(/\r\n/g, '\n');
  return normalized.endsWith('\n') ? normalized : `${normalized}\n`;
}

async function writeEphemeralPrivateKey(privateKey) {
  const keyPath = path.join(os.tmpdir(), `ipingyou_client_${Date.now()}`);
  fs.writeFileSync(keyPath, normalizePrivateKey(privateKey), { mode: 0o600 });

  const result = await execa('ssh-keygen', ['-y', '-f', keyPath], {
    reject: false,
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  if (result.exitCode !== 0) {
    try { fs.unlinkSync(keyPath); } catch { }
    throw new Error(result.stderr.trim() || 'OpenSSH could not parse the host-provided private key');
  }

  return keyPath;
}

/**
 * Start SSH connection through the Cloudflare tunnel.
 */
async function connectSSH(username, hostname, privateKeyPath, persistKnownHosts = true) {
  console.log('');
  console.log(chalk.bold('  🔗 Establishing SSH Connection'));
  console.log(chalk.dim('  ─────────────────────────────────'));

  await showConnectionTrace('Local', 'Remote SSH');

  try {
    const spinner = createSpinner('Handshaking...', sshSpinner).start();
    await new Promise(r => setTimeout(r, 800));
    spinner.succeed('Connection established! Handing over to terminal...');
    console.log('');

    const sshArgs = buildSshArgs(hostname, privateKeyPath, [
      '-o', 'ServerAliveInterval=30',
      '-o', 'ServerAliveCountMax=3'
    ], { persistKnownHosts });

    sshArgs.push(`${username}@${hostname}`);
    const tmuxSession = buildTmuxSessionName(username);
    const quotedSocket = quoteRemoteShell(TMUX_SOCKET_PATH);
    const quotedSession = quoteRemoteShell(tmuxSession);
    const tmuxSocketCmdStr = `tmux -S ${quotedSocket}`;
    const tmuxPrepare = `${tmuxSocketCmdStr} has-session -t ${quotedSession} 2>/dev/null || ${tmuxSocketCmdStr} new-session -d -s ${quotedSession}`;
    const tmuxAttach = `${tmuxSocketCmdStr} attach -t ${quotedSession}`;
    const tmuxCommand = `if command -v tmux >/dev/null 2>&1; then (${tmuxPrepare} && ${tmuxAttach}) || exec $SHELL -l; else exec $SHELL -l; fi`;
    sshArgs.push('-t', tmuxCommand);

    const child = execa('ssh', sshArgs, {
      stdio: 'inherit',
      reject: false,
    });

    trackPID(child.pid);
    const result = await child;
    untrackPID(child.pid);

    if (result.exitCode === 0) {
      console.log('');
      console.log(chalk.green('  ✅ SSH session ended cleanly'));
      recordEvent('ssh_session_ended', { hostname, exitCode: 0 });
    } else if (result.exitCode === 255) {
      console.log('');
      console.error(chalk.red('  ❌ SSH connection failed (exit code 255)'));
      recordEvent('ssh_session_failed', { hostname, exitCode: 255 });
    } else {
      console.log('');
      console.error(chalk.red(`  ❌ SSH exited with code ${result.exitCode}`));
      recordEvent('ssh_session_ended', { hostname, exitCode: result.exitCode });
    }
  } catch (err) {
    console.error(chalk.red(`  ❌ SSH error: ${err.message}`));
  }
}

/**
 * Perform an SCP file transfer through the Cloudflare tunnel.
 */
async function chooseRemoteTransferPath(username, hostname, privateKeyPath, direction, sharedDropPath, persistKnownHosts = true) {
  if (!sharedDropPath) {
    return promptRemotePath(username, hostname, privateKeyPath, direction === 'upload' ? 'destination' : 'source', '~', { persistKnownHosts });
  }

  const { dropChoice } = await inquirer.prompt([{
    type: 'list',
    name: 'dropChoice',
    message: direction === 'upload'
      ? 'Where should the file/folder go on the host?'
      : 'Where should browsing start on the host?',
    choices: direction === 'upload'
      ? [
        { name: `📥 Use host shared drop folder (${sharedDropPath})`, value: 'drop' },
        { name: '🔍 Browse host folders', value: 'browse' },
        { name: '⌨️  Type host destination path manually', value: 'manual' }
      ]
      : [
        { name: `📥 Start in host shared drop folder (${sharedDropPath})`, value: 'drop_browse' },
        { name: '🔍 Browse from host home folder', value: 'browse' },
        { name: '⌨️  Type host file/folder path manually', value: 'manual' }
      ]
  }]);

  if (dropChoice === 'drop') return sharedDropPath;
  if (dropChoice === 'drop_browse') {
    return promptRemotePath(username, hostname, privateKeyPath, 'source', sharedDropPath, { persistKnownHosts });
  }
  if (dropChoice === 'manual') {
    const { remotePath } = await inquirer.prompt([{
      type: 'input',
      name: 'remotePath',
      message: direction === 'upload' ? 'Host destination path:' : 'Host file/folder path:',
      validate: v => v.trim().length > 0 || 'Required',
    }]);
    return remotePath.trim();
  }

  return promptRemotePath(username, hostname, privateKeyPath, direction === 'upload' ? 'destination' : 'source', '~', { persistKnownHosts });
}

async function performSCP(username, hostname, direction, privateKeyPath, sharedDropPath = null, persistKnownHosts = true) {
  console.log('');
  console.log(chalk.bold(`  📦 SCP Transfer (${direction})`));
  console.log(chalk.dim('  ─────────────────────────────────'));

  let localPath;
  let remotePath;

  if (direction === 'upload') {
    remotePath = await chooseRemoteTransferPath(username, hostname, privateKeyPath, direction, sharedDropPath, persistKnownHosts);
    localPath = await promptLocalPath('client file/folder to upload');
  } else {
    localPath = await promptLocalPath('client destination');
    remotePath = await chooseRemoteTransferPath(username, hostname, privateKeyPath, direction, sharedDropPath, persistKnownHosts);
  }

  await showConnectionTrace('Local', 'Remote SCP');

  const proxyCommand = `cloudflared access tcp --hostname ${hostname}`;

  // Construct SCP args
  const scpArgs = [
    '-r', // recursive just in case
    '-o', `ProxyCommand=${proxyCommand}`,
    ...getKnownHostsOptions(persistKnownHosts),
    '-o', 'IdentitiesOnly=yes',
    ...getSshControlOptions(hostname)
  ];

  if (privateKeyPath) {
    scpArgs.push('-i', privateKeyPath, '-o', 'IdentityAgent=none');
  }

  const remoteSpec = `${username}@${hostname}:${formatScpRemotePath(remotePath)}`;
  if (direction === 'upload') {
    scpArgs.push(localPath, remoteSpec);
  } else {
    // Download: remote source FIRST, then local destination
    scpArgs.push(remoteSpec, localPath);
  }

  let localHash = null;
  if (direction === 'upload') {
    console.log(chalk.dim('  🔍 Calculating local SHA-256 checksum...'));
    localHash = await calculateChecksum(localPath);
    if (localHash) console.log(chalk.dim(`     Hash: ${localHash.substring(0, 16)}...`));
  }

  try {
    const transferSpinner = createSpinner(`Transferring via SCP...`, fileTransferSpinner).start();

    const child = execa('scp', scpArgs, {
      stdio: ['inherit', 'pipe', 'pipe'],
      reject: false,
    });

    trackPID(child.pid);
    const result = await child;
    untrackPID(child.pid);

    transferSpinner.stop();

    if (result.exitCode === 0) {
      await simulateTransferProgress(direction === 'upload' ? localPath : remotePath, direction, 1500);

      // Verify Checksum
      if (direction === 'upload' && localHash) {
        console.log(chalk.dim('  🔍 Verifying remote SHA-256 checksum...'));
        try {
          const remoteChecksumPath = joinRemotePath(remotePath, path.basename(localPath));
          const sshArgs = buildSshArgs(hostname, privateKeyPath, [], { persistKnownHosts });
          sshArgs.push(`${username}@${hostname}`, `shasum -a 256 ${quoteRemoteShell(remoteChecksumPath)} 2>/dev/null || sha256sum ${quoteRemoteShell(remoteChecksumPath)} 2>/dev/null || shasum -a 256 ${quoteRemoteShell(remotePath)} 2>/dev/null || sha256sum ${quoteRemoteShell(remotePath)}`);

          const { stdout } = await execa('ssh', sshArgs, { reject: false });
          const remoteHash = stdout.split(' ')[0].trim();

          if (remoteHash === localHash) {
            console.log(chalk.green(`  ✅ Zero-Trust File Integrity: Hash match (${remoteHash.substring(0, 16)}...)`));
          } else {
            console.log(chalk.yellow(`  ⚠️ Warning: Remote checksum could not be verified automatically.`));
          }
        } catch {
          console.log(chalk.dim('     Could not run remote checksum validation.'));
        }
      } else if (direction === 'download') {
        console.log(chalk.dim('  🔍 Calculating downloaded SHA-256 checksum...'));
        const dlHash = await calculateChecksum(localPath);
        if (dlHash) console.log(chalk.green(`  ✅ File Intact. Hash: ${dlHash.substring(0, 16)}...`));
      }

      console.log(chalk.green(`  ✅ Transfer completed successfully!`));
      recordEvent('scp_transfer_success', { direction, localPath, remotePath, hostname });
    } else {
      console.error(chalk.red('  ❌ SCP transfer failed'));
      if (result.stderr) console.error(chalk.dim(`     ${result.stderr.trim()}`));
      recordEvent('scp_transfer_failed', { direction, localPath, remotePath, hostname, error: result.stderr });
    }
  } catch (err) {
    console.error(chalk.red(`  ❌ SCP error: ${err.message}`));
  }
}

async function downloadSpecificRemotePath(username, hostname, privateKeyPath, remotePath, localPath, persistKnownHosts = true) {
  await showConnectionTrace('Local', 'Remote SCP');
  const proxyCommand = `cloudflared access tcp --hostname ${hostname}`;
  const scpArgs = [
    '-r',
    '-o', `ProxyCommand=${proxyCommand}`,
    ...getKnownHostsOptions(persistKnownHosts),
    '-o', 'IdentitiesOnly=yes',
    ...getSshControlOptions(hostname),
  ];
  if (privateKeyPath) scpArgs.push('-i', privateKeyPath, '-o', 'IdentityAgent=none');
  scpArgs.push(`${username}@${hostname}:${formatScpRemotePath(remotePath)}`, localPath);
  const result = await execa('scp', scpArgs, { stdio: 'inherit', reject: false });
  return result.exitCode === 0;
}

function joinRemotePath(parent, child) {
  const cleanParent = String(parent || '').replace(/\/+$/, '');
  if (!cleanParent) return child;
  if (cleanParent === '/') return `/${child}`;
  return `${cleanParent}/${child}`;
}

/**
 * Main Client Mode entry point.
 */
export async function startClientMode(options = {}) {
  console.log('');
  console.log(chalk.bold.cyan('  🌐 CLIENT MODE — Access a Remote Machine'));
  console.log(chalk.dim('  ──────────────────────────────────────────'));
  console.log('');

  const sessionLogPath = initSessionLog('client');
  if (sessionLogPath) {
    console.log(chalk.dim(`  📜 Session log: ${sessionLogPath}`));
    addCleanupHook(() => cleanupSessionLog());
  }
  logSessionEvent('client_mode_started');

  // Allow setting a custom broker URL if process.env isn't overridden by CLI
  if (process.env.BROKER_URL) {
    BROKER_URL = process.env.BROKER_URL;
  } else {
    const { brokerChoice } = await inquirer.prompt([
      {
        type: 'list',
        name: 'brokerChoice',
        message: 'Which Broker Server is the Host using?',
        choices: [
          { name: '🌍 Global Public Broker (Render) [Default]', value: 'global' },
          { name: '🔗 Custom Private Broker (URL)', value: 'custom' }
        ]
      }
    ]);
    if (brokerChoice === 'custom') {
      const { customBroker } = await inquirer.prompt([
        {
          type: 'input',
          name: 'customBroker',
          message: 'Enter the Private Broker URL provided by the host:',
          validate: v => v.trim().startsWith('http') || 'Must be a valid URL starting with http/https'
        }
      ]);
      BROKER_URL = customBroker.trim();
      process.env.BROKER_URL = BROKER_URL; // Update for consistency
    }
    logSessionEvent('client_broker_selected', { choice: brokerChoice, broker: BROKER_URL });
  }

  const config = getConfig();
  const aliasKeys = Object.keys(config.aliases || {});

  let targetUid = null;
  let targetPassword = null;
  let targetUsername = null;
  let persistKnownHosts = false;

  if (aliasKeys.length > 0) {
    const { useAlias } = await inquirer.prompt([
      {
        type: 'list',
        name: 'useAlias',
        message: 'Select a saved connection or enter manually:',
        choices: [
          ...aliasKeys.map(k => ({ name: `🔖 ${k} (${config.aliases[k].uid})`, value: k })),
          { name: '✍️  Enter UID manually', value: 'manual' }
        ]
      }
    ]);

    if (useAlias !== 'manual') {
      const aliasData = config.aliases[useAlias];
      targetUid = aliasData.uid;
      targetPassword = aliasData.password;
      targetUsername = aliasData.username;
      persistKnownHosts = true;
      logSessionEvent('client_alias_selected', { alias: useAlias, uid: targetUid });
    }
  }

  if (!targetUid && options.uid) {
    targetUid = options.uid.trim();
    const { password } = await inquirer.prompt([{
      type: 'password',
      name: 'password',
      message: 'Enter the session password:',
      validate: (v) => v.trim().length > 0 || 'Password is required to decrypt',
    }]);
    targetPassword = password.trim();
    logSessionEvent('client_uid_provided', { uid: targetUid });
  }

  if (!targetUid) {
    const answer = await inquirer.prompt([
      {
        type: 'input',
        name: 'uid',
        message: 'Enter the remote host\'s UID:',
        validate: (v) => {
          const trimmed = v.trim();
          if (trimmed.length < 6 || trimmed.length > 16) return 'UID must be 6-16 characters';
          if (!/^[a-z0-9]+$/.test(trimmed)) return 'UID should be lowercase alphanumeric';
          return true;
        },
      },
      {
        type: 'password',
        name: 'password',
        message: 'Enter the session password:',
        validate: (v) => v.trim().length > 0 || 'Password is required to decrypt',
      }
    ]);
    targetUid = answer.uid.trim();
    targetPassword = answer.password.trim();
    logSessionEvent('client_uid_provided', { uid: targetUid });
  }

  let payload = await resolveUID(BROKER_URL, targetUid, targetPassword);

  // ─── Approval Flow ──────────────────────────────────────────
  if (payload && payload.needsApproval) {
    console.log('');
    console.log(chalk.bold.yellow('  🔐 Host Approval Required'));
    console.log(chalk.dim('  ──────────────────────────────────────'));
    console.log(chalk.dim('  The host has enabled approval gating. Submitting your access request...'));

    try {
      const approvalDetails = {
        username: os.userInfo().username,
        hostname: os.hostname(),
        os: `${os.type()} ${os.release()} (${os.arch()})`,
        intent: 'connect',
        time: new Date().toISOString(),
      };

      const { requestId, status: reqStatus, approvalRequired } = await requestHostApproval(
        BROKER_URL, targetUid, targetPassword, approvalDetails
      );

      logSessionEvent('client_approval_submitted', { uid: targetUid, requestId });

      if (!approvalRequired || reqStatus === 'approved') {
        console.log(chalk.green('  ✅ Access auto-approved (host does not require manual approval for this session).'));
        payload = await resolveUID(BROKER_URL, targetUid, targetPassword, false, requestId);
      } else {
        console.log(chalk.yellow(`  ⏳ Waiting for host to approve your request (ID: ${requestId})...`));
        console.log(chalk.dim('     This may take a few minutes. Press Ctrl+C to cancel.'));
        console.log('');

        const approved = await waitForApproval(BROKER_URL, targetUid, requestId, 300000);

        if (approved) {
          console.log(chalk.green('  ✅ Host approved your access request!'));
          logSessionEvent('client_approval_granted', { uid: targetUid, requestId });
          payload = await resolveUID(BROKER_URL, targetUid, targetPassword, false, requestId);
        } else {
          console.log(chalk.red('  ❌ Host denied your access request.'));
          logSessionEvent('client_approval_denied', { uid: targetUid, requestId });
          process.exit(1);
        }
      }
    } catch (err) {
      console.log(chalk.red(`  ❌ Approval flow failed: ${err.message}`));
      logSessionEvent('client_approval_error', { uid: targetUid, error: err.message }, 'error');
      process.exit(1);
    }
  }

  if (!payload || payload.needsApproval) {
    process.exit(1);
  }

  if (payload.type === 'http') {
    console.log('');
    console.log(chalk.bold('  🌐 HTTP Service Exposed'));
    console.log(chalk.dim('  ─────────────────────────────────'));
    console.log(chalk.green(`  Opening in browser: ${chalk.bold.cyan(payload.url)}`));
    console.log('');
    logSessionEvent('client_http_mode', { uid: targetUid, port: payload.port || null });
    try {
      await open(payload.url);
    } catch {
      console.log(chalk.dim(`  Could not auto-open. Please visit: ${payload.url}`));
    }
    console.log(chalk.dim('  Press Ctrl+C to exit.'));
    // Keep process alive so cleanup handlers work
    await new Promise(() => {});
  }

  if (payload.type === 'tcp') {
    console.log('');
    console.log(chalk.bold('  🔌 Custom TCP Port Exposed'));
    console.log(chalk.dim('  ─────────────────────────────────'));
    console.log(`  The host is exposing a generic TCP service on port ${payload.port}.`);

    const hostname = extractHostname(payload.url);
    const localPort = payload.port;

    console.log(chalk.dim(`  Starting local cloudflared proxy to ${hostname}...`));
    console.log('');

    try {
      const { execa: execaFn } = await import('execa');
      const child = execaFn('cloudflared', ['access', 'tcp', '--hostname', hostname, '--url', `127.0.0.1:${localPort}`], {
        stdio: 'inherit',
        reject: false,
      });

      trackPID(child.pid);
      console.log(chalk.green(`  ✅ Local proxy active! Connect your client to ${chalk.bold('127.0.0.1:' + localPort)}`));
      console.log(chalk.dim('  Press Ctrl+C to terminate the tunnel.'));
      logSessionEvent('client_tcp_mode', { uid: targetUid, port: localPort, hostname });

      const result = await child;
      untrackPID(child.pid);

      if (result.exitCode !== 0) {
        console.log(chalk.red(`  ❌ Cloudflared exited with code ${result.exitCode}`));
      }
    } catch (err) {
      console.log(chalk.red(`  ❌ Could not start cloudflared proxy: ${err.message}`));
      console.log(chalk.dim('  Fallback: run manually in another terminal:'));
      console.log(chalk.cyan(`  cloudflared access tcp --hostname ${hostname} --url 127.0.0.1:${localPort}`));
      console.log('');
      console.log(`  Then connect your local client to ${chalk.green('127.0.0.1:' + localPort)}`);
    }
    await cleanupAll();
    return;
  }

  const tunnelUrl = payload.url;
  const username = targetUsername || await promptUsername();
  const hostname = extractHostname(tunnelUrl);

  // Setup Ephemeral Key if provided
  let privateKeyPath = null;
  if (payload.privateKey) {
    console.log(chalk.green('  🔑 Host provided an ephemeral SSH key for passwordless entry!'));
    try {
      privateKeyPath = await writeEphemeralPrivateKey(payload.privateKey);
      addCleanupHook(() => {
        try { fs.unlinkSync(privateKeyPath); } catch { }
      });
      logSessionEvent('client_ephemeral_key_ready');
    } catch (err) {
      console.log(chalk.yellow(`  ⚠️  Could not use ephemeral SSH key: ${err.message}`));
      console.log(chalk.dim('     Falling back to standard OS password.'));
      logSessionEvent('client_ephemeral_key_failed', { error: err.message }, 'warn');
      privateKeyPath = null;
    }
  }

  // ─── One-Time File Share Auto-Download ────────────────────
  if (payload.oneTime && payload.oneTimeSharePath) {
    console.log('');
    console.log(chalk.bold.magenta('  📦 One-Time File Share'));
    console.log(chalk.dim('  ──────────────────────────────────────'));
    console.log(chalk.dim(`  Host is sharing: ${chalk.cyan(payload.oneTimeSharePath)}`));
    console.log(chalk.dim('  This is a one-time transfer — the session will be revoked after download.'));
    console.log('');

    const localDest = await promptLocalPath('download destination');

    await pushTelemetry(BROKER_URL, targetUid, targetPassword, username, 'one-time-download');
    logSessionEvent('client_one_time_download_start', { uid: targetUid, remotePath: payload.oneTimeSharePath });

    const success = await downloadSpecificRemotePath(username, hostname, privateKeyPath, payload.oneTimeSharePath, localDest, persistKnownHosts);

    if (success) {
      console.log(chalk.green('  ✅ One-time file transfer completed successfully!'));

      // Verify download checksum
      const dlHash = await calculateChecksum(localDest);
      if (dlHash) console.log(chalk.green(`  🔍 File Intact. SHA-256: ${dlHash.substring(0, 16)}...`));

      // Auto-revoke the UID from broker
      console.log(chalk.dim('  Revoking session from broker...'));
      await revokeUID(BROKER_URL, targetUid);
      console.log(chalk.green('  🔒 Session revoked. No further access is possible.'));

      logSessionEvent('client_one_time_download_complete', { uid: targetUid });
      recordEvent('one_time_transfer_complete', { uid: targetUid, localDest });
    } else {
      console.log(chalk.red('  ❌ One-time file transfer failed.'));
      logSessionEvent('client_one_time_download_failed', { uid: targetUid }, 'error');
    }

    await cleanupAll();
    return;
  }

  // Ask to save alias if we entered manually
  if (!targetUsername) {
    const { saveIt } = await inquirer.prompt([{
      type: 'confirm',
      name: 'saveIt',
      message: 'Save this connection as an alias for quick access later?',
      default: false
    }]);

    if (saveIt) {
      const { aliasName } = await inquirer.prompt([{
        type: 'input',
        name: 'aliasName',
        message: 'Enter alias name (e.g. my-server):',
        validate: v => v.trim().length > 0 || 'Required'
      }]);
      saveAlias(aliasName.trim(), { uid: targetUid, password: targetPassword, username });
      console.log(chalk.green(`  ✓ Saved as alias: ${chalk.bold(aliasName.trim())}\n`));
      logSessionEvent('client_alias_saved', { alias: aliasName.trim(), uid: targetUid });
      persistKnownHosts = true;
    }
  }

  const { action } = await inquirer.prompt([
    {
      type: 'list',
      name: 'action',
      message: 'What would you like to do?',
      choices: [
        { name: '🖥️  Connect via SSH (Interactive Shell)', value: 'ssh' },
        { name: '📤 Upload file/folder via SCP', value: 'upload' },
        { name: '📥 Download file/folder via SCP', value: 'download' },
        { name: '🔄 Expose local port to Host (Reverse Tunnel)', value: 'reverse' },
        { name: '💬 Join Host Chat Room', value: 'chat' }
      ]
    }
  ]);

  await pushTelemetry(BROKER_URL, targetUid, targetPassword, username, action);
  logSessionEvent('client_action_selected', { action });

  if (action === 'chat') {
    await handleClientChat(targetUid, targetPassword, payload.chatUrl);
  } else if (action === 'ssh') {
    await connectSSH(username, hostname, privateKeyPath, persistKnownHosts);
  } else if (action === 'reverse') {
    await performReverseForward(username, hostname, privateKeyPath, persistKnownHosts);
  } else {
    await performSCP(username, hostname, action, privateKeyPath, payload.sharedDropPath, persistKnownHosts);
  }

  console.log('');
  const { reconnect } = await inquirer.prompt([
    {
      type: 'confirm',
      name: 'reconnect',
      message: 'Perform another action with the same host?',
      default: false,
    },
  ]);

  if (reconnect) {
    await handleSubsequentActions(username, hostname, privateKeyPath, targetUid, targetPassword, payload.sharedDropPath, persistKnownHosts);
  }

  logSessionEvent('client_session_exit');
  await cleanupAll();
}

/**
 * Perform a non-interactive SCP transfer (used by AI Transfer Assistant).
 * params: { brokerUrl, uid, password, username, direction, localPath, remotePath }
 */
export async function performSCPNonInteractive(params = {}) {
  const { brokerUrl, uid, password, username, direction, localPath, remotePath, persistKnownHosts = true } = params;
  if (!brokerUrl || !uid || !password) throw new Error('Missing broker connection info');

  const payload = await resolveUID(brokerUrl, uid, password);
  if (!payload) throw new Error('Could not resolve UID/payload');

  const tunnelUrl = payload.url;
  const hostname = extractHostname(tunnelUrl);
  const privateKeyPath = payload.privateKey ? await writeEphemeralPrivateKey(payload.privateKey) : null;

  // Build scp args similar to performSCP
  const proxyCommand = `cloudflared access tcp --hostname ${hostname}`;
  const scpArgs = ['-r', '-o', `ProxyCommand=${proxyCommand}`, ...getKnownHostsOptions(persistKnownHosts), '-o', 'IdentitiesOnly=yes', ...getSshControlOptions(hostname)];
  if (privateKeyPath) scpArgs.push('-i', privateKeyPath, '-o', 'IdentityAgent=none');

  const remoteSpec = `${username}@${hostname}:${formatScpRemotePath(remotePath)}`;
  if (direction === 'upload') {
    scpArgs.push(localPath, remoteSpec);
  } else {
    scpArgs.push(remoteSpec, localPath);
  }

  try {
    const result = await execa('scp', scpArgs, { stdio: 'inherit', reject: false });
    if (result.exitCode === 0) {
      recordEvent('scp_transfer_success', { direction, localPath, remotePath, hostname, automated: true });
      return true;
    }
    recordEvent('scp_transfer_failed', { direction, localPath, remotePath, hostname, error: result.stderr, automated: true });
    return false;
  } finally {
    try { if (privateKeyPath) fs.unlinkSync(privateKeyPath); } catch { }
  }
}

async function handleClientChat(uid, password, cachedChatUrl) {
  let chatUrl = cachedChatUrl;
  const spinner = createSpinner('Checking for active chat room...', networkSpinner).start();

  const payload = await resolveUID(BROKER_URL, uid, password, true); // true = silent if possible, or just re-resolve
  if (payload && payload.chatUrl) {
    chatUrl = payload.chatUrl;
  }

  if (chatUrl) {
    spinner.succeed('Chat Room found! Opening browser...');
    try {
      const fullUrl = `${chatUrl}#${password}`;
      await open(fullUrl);
    } catch {
      console.log(chalk.cyan(`  👉 Please open: ${secureSensitiveUrl(chatUrl, password)}`));
    }
  } else {
    spinner.warn('The host has not started a chat room yet.');
  }
}

async function handleSubsequentActions(username, hostname, privateKeyPath, targetUid, targetPassword, sharedDropPath = null, persistKnownHosts = true) {
  const { action } = await inquirer.prompt([
    {
      type: 'list',
      name: 'action',
      message: 'What would you like to do next?',
      choices: [
        { name: '🖥️  Connect via SSH', value: 'ssh' },
        { name: '📤 Upload file/folder via SCP', value: 'upload' },
        { name: '📥 Download file/folder via SCP', value: 'download' },
        { name: '🔄 Expose local port to Host (Reverse Tunnel)', value: 'reverse' },
        { name: '💬 Join Host Chat Room', value: 'chat' },
        { name: '❌ Exit', value: 'exit' }
      ]
    }
  ]);

  if (action === 'exit') return;

  await pushTelemetry(BROKER_URL, targetUid, targetPassword, username, action);
  logSessionEvent('client_action_selected', { action });

  if (action === 'chat') {
    await handleClientChat(targetUid, targetPassword, null);
  } else if (action === 'ssh') {
    await connectSSH(username, hostname, privateKeyPath, persistKnownHosts);
  } else if (action === 'reverse') {
    await performReverseForward(username, hostname, privateKeyPath, persistKnownHosts);
  } else {
    await performSCP(username, hostname, action, privateKeyPath, sharedDropPath, persistKnownHosts);
  }

  const { reconnect } = await inquirer.prompt([
    {
      type: 'confirm',
      name: 'reconnect',
      message: 'Perform another action?',
      default: false,
    },
  ]);

  if (reconnect) {
    await handleSubsequentActions(username, hostname, privateKeyPath, targetUid, targetPassword, sharedDropPath, persistKnownHosts);
  }
}

async function performReverseForward(username, hostname, privateKeyPath, persistKnownHosts = true) {
  console.log('');
  console.log(chalk.bold.cyan('  🔄 Reverse Port Forwarding'));
  console.log(chalk.dim('  ──────────────────────────────────────'));
  console.log(chalk.dim('  Expose a local port on your machine so the Host can access it.'));
  console.log('');

  const { localPort, remotePort } = await inquirer.prompt([
    {
      type: 'input',
      name: 'localPort',
      message: 'Enter your local port to expose (e.g., 3000):',
      validate: (v) => !isNaN(parseInt(v)) || 'Must be a number',
    },
    {
      type: 'input',
      name: 'remotePort',
      message: 'Enter the port to bind on the Host (e.g., 8080):',
      default: '8080',
      validate: (v) => !isNaN(parseInt(v)) || 'Must be a number',
    }
  ]);

  const portMap = `${remotePort}:localhost:${localPort}`;

  const sshArgs = buildSshArgs(hostname, privateKeyPath, [
    '-N',
    '-R', portMap,
    '-o', 'ExitOnForwardFailure=yes',
  ], { persistKnownHosts });
  sshArgs.push(`${username}@${hostname}`);

  console.log('');
  const spinner = createSpinner(`Forwarding Host:${remotePort} ➔ Localhost:${localPort}...`, networkSpinner).start();

  let child = null;
  try {
    child = execa('ssh', sshArgs, { stdio: 'inherit', reject: false });
    trackPID(child.pid);
    spinner.succeed(`Reverse tunnel active! Host can access your app at ${chalk.bold.green('localhost:' + remotePort)}`);
    console.log(chalk.dim('  Press Ctrl+C to terminate the reverse tunnel.'));

    recordEvent('reverse_forward_started', { localPort, remotePort, hostname });
    const result = await child;
    if (result.exitCode === 0) {
      recordEvent('reverse_forward_ended', { localPort, remotePort, hostname, exitCode: 0 });
    } else {
      console.log(chalk.red(`\n  ❌ Reverse tunnel exited with code ${result.exitCode}`));
      recordEvent('reverse_forward_failed', { localPort, remotePort, hostname, exitCode: result.exitCode });
    }
  } catch (err) {
    if (err.isCanceled) return;
    if (err.killed) return;
    spinner.fail('Reverse tunnel failed to start');
    console.log(chalk.red(`\n  ❌ Tunnel disconnected: ${err.message}`));
  } finally {
    if (child?.pid) untrackPID(child.pid);
  }
}
